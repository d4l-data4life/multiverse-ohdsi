# strategusMultiverse

Reads OHDSI Strategus / CohortMethod results and renders multiverse
visualisations. One entry point:

```r
multiverse("path/to/resultsFolder", type = "specification_curve")
```

## Install

```r
remotes::install_github("<you>/strategusMultiverse")
```

## Use

```r
library(strategusMultiverse)

mv <- readStrategusMultiverse("resultsFolder")
mv          # what was found: specifications, decisions, estimate range
summary(mv) # median, range, % above null, % significant, % passing diagnostics

multiverse(mv, type = "specification_curve")   # Simonsohn et al.
multiverse(mv, type = "multiverse")            # Krahmer & Young
multiverse(mv, type = "volcano")               # vibration of effects
multiverse(mv, type = "influence")             # which decisions move the estimate
multiverse(mv, type = "gate")                  # before/after diagnostic pruning
multiverse(mv, type = "shiny")                 # interactive explorer

varianceDecomposition(mv)
exportMultiverse(mv, "multiverse.csv")
```

`type` also accepts a results-folder path directly, so the shortest form is a
single call:

```r
multiverse("resultsFolder", type = "multiverse")
```

## What it reads

Files are located by recursive search, since layouts differ across Strategus
versions:

| File | Used for |
|---|---|
| `cm_result.csv` | estimates, intervals, p-values, counts |
| `cm_diagnostics_summary.csv` | `unblind` and the individual diagnostics |
| `analysisSpecification.json` | the specification grid (preferred) |
| `cm_analysis.csv` | the specification grid (fallback) |

## How the specification grid is recovered

Every `cmAnalysis` object in the analysis specification is flattened into
`name = value` pairs, and any field taking more than one value across analyses
becomes a decision column. Nothing is hardcoded: adding a new axis to the
Strategus script makes it appear here automatically. Absent arguments are
recorded as `"none"`, because "no trimming" is itself an analytical choice, and
arguments that do not apply to a family (a caliper for a stratified analysis)
are recorded as `"not applicable"` and omitted from dashboards.

## Choosing a visualisation

Specification curves lose their decision dashboard above roughly 200-300
specifications; the package warns when you cross that. Above it, use
`type = "multiverse"`, which pairs a density of the modelling distribution with
a binned dashboard and so scales to thousands of specifications.

## Caveats

Variance decomposition shares are a property of the option set you enumerated,
not of the decision category in the abstract. Widening or narrowing the options
within a decision changes its share. Report the grid alongside the numbers.

## References

- Simonsohn U, Simmons JP, Nelson LD. Specification curve analysis. *Nat Hum Behav* 2020.
- Krahmer D, Young C. Visualizing vastness: graphical methods for multiverse analysis. *PLOS One* 2026. Code: https://osf.io/64wxf/
- Patel CJ, Burford B, Ioannidis JPA. Assessment of vibration of effects. *J Clin Epidemiol* 2015.
- Conover MM, et al. Objective study validity diagnostics. *JAMIA* 2025.
