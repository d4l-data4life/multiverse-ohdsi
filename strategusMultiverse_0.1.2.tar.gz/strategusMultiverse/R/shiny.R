#' Interactive multiverse explorer
#'
#' A Shiny app for exploring a Strategus multiverse. Three tabs: static
#' visualisations, an interactive volcano plot with per-specification tooltips,
#' and the specification table.
#'
#' The interactive volcano uses \pkg{plotly} when available. Without it, the app
#' falls back to a plot with hover: moving the cursor over a point shows the same
#' specification detail in a panel beneath it.
#'
#' @param x A `strategus_multiverse`, or a path to a Strategus results folder.
#' @param estimate Column holding the point estimate.
#' @param ... Passed to `shiny::runApp()`.
#' @export
launchMultiverseApp <- function(x, estimate = "rr", ...) {
  if (!requireNamespace("shiny", quietly = TRUE)) {
    stop("Install 'shiny' to use the interactive explorer.")
  }
  if (is.character(x)) x <- readStrategusMultiverse(x)
  d <- x$estimates
  decs <- x$decisions
  hasDiag <- "passesDiagnostics" %in% names(d)
  hasPlotly <- requireNamespace("plotly", quietly = TRUE)
  estChoices <- intersect(c("rr", "calibrated_rr"), names(d))

  volcanoTab <- if (hasPlotly) {
    shiny::tabPanel(
      "Interactive volcano",
      shiny::helpText("Hover a point for the full specification behind it."),
      plotly::plotlyOutput("volcano", height = "640px")
    )
  } else {
    shiny::tabPanel(
      "Interactive volcano",
      shiny::helpText(
        "Install 'plotly' for hover tooltips. Falling back to hover-with-detail: ",
        "move the cursor over a point and its specification appears below."),
      shiny::plotOutput("volcanoStatic", height = "560px",
                        hover = shiny::hoverOpts("vhover", delay = 80,
                                                 delayType = "debounce")),
      shiny::wellPanel(shiny::verbatimTextOutput("volcanoHover"))
    )
  }

  ui <- shiny::fluidPage(
    shiny::titlePanel("Strategus multiverse explorer"),
    shiny::sidebarLayout(
      shiny::sidebarPanel(
        width = 3,
        shiny::selectInput("type", "Visualisation",
          c("Specification curve" = "specification_curve",
            "Multiverse plot"     = "multiverse",
            "Density"             = "density",
            "Volcano"             = "volcano",
            "Influence"           = "influence",
            "Diagnostic gate"     = "gate")),
        shiny::selectInput("estimate", "Estimate", estChoices, selected = estimate),
        shiny::checkboxInput("log", "Log scale", TRUE),
        if (hasDiag) shiny::checkboxInput("gate", "Diagnostic-passing only", FALSE),
        shiny::selectInput("colourBy", "Colour volcano by",
                           c("(default)", decs), selected = "(default)"),
        shiny::hr(),
        shiny::helpText("Filter specifications:"),
        lapply(seq_along(decs), function(i) {
          dn <- decs[i]
          shiny::selectInput(paste0("f_", i), dn,
                             choices = c("(all)", sort(unique(as.character(d[[dn]])))),
                             selected = "(all)")
        }),
        shiny::hr(),
        shiny::downloadButton("dl", "Download table (CSV)")
      ),
      shiny::mainPanel(
        width = 9,
        shiny::verbatimTextOutput("summary"),
        shiny::tabsetPanel(
          shiny::tabPanel("Visualisation",
                          shiny::plotOutput("plot", height = "620px")),
          volcanoTab,
          shiny::tabPanel("Specifications",
                          shiny::tableOutput("table"))
        )
      )
    )
  )

  server <- function(input, output, session) {

    filtered <- shiny::reactive({
      obj <- x
      dd <- obj$estimates
      for (i in seq_along(decs)) {
        v <- input[[paste0("f_", i)]]
        if (!is.null(v) && v != "(all)") {
          dd <- dd[as.character(dd[[decs[i]]]) == v, ]
        }
      }
      if (isTRUE(input$gate) && "passesDiagnostics" %in% names(dd)) {
        dd <- dd[which(dd$passesDiagnostics), ]
      }
      obj$estimates <- dd
      obj
    })

    colourBy <- shiny::reactive({
      if (is.null(input$colourBy) || input$colourBy == "(default)") NULL
      else input$colourBy
    })

    output$summary <- shiny::renderPrint({
      shiny::validate(shiny::need(nrow(filtered()$estimates) > 0,
                                  "No specifications match these filters."))
      summary(filtered(), estimate = input$estimate)
    })

    output$plot <- shiny::renderPlot({
      shiny::validate(shiny::need(nrow(filtered()$estimates) > 1,
                                  "Need at least two specifications to plot."))
      multiverse(filtered(), type = input$type, estimate = input$estimate,
                 log = input$log)
    })

    if (hasPlotly) {
      output$volcano <- plotly::renderPlotly({
        shiny::validate(shiny::need(nrow(filtered()$estimates) > 0,
                                    "No specifications match these filters."))
        plotVolcanoInteractive(filtered(), estimate = input$estimate,
                               log = input$log, colourBy = colourBy())
      })
    } else {
      volcanoData <- shiny::reactive({
        dd <- .prep(filtered(), input$estimate, input$log)
        shiny::validate(shiny::need("p" %in% names(dd),
                                    "No 'p' column; cannot draw a volcano plot."))
        dd$.negLogP <- -log10(pmax(dd$p, .Machine$double.xmin))
        dd$.tooltip <- .tooltipText(dd, decs, input$estimate)
        dd
      })

      output$volcanoStatic <- shiny::renderPlot({
        plotVolcano(filtered(), estimate = input$estimate, log = input$log,
                    colourBy = colourBy())
      })

      output$volcanoHover <- shiny::renderText({
        dd <- volcanoData()
        hv <- input$vhover
        if (is.null(hv)) return("Hover a point to see its specification.")
        near <- shiny::nearPoints(dd, hv, xvar = ".est", yvar = ".negLogP",
                                  threshold = 12, maxpoints = 1)
        if (nrow(near) == 0) return("Hover a point to see its specification.")
        near$.tooltip[1]
      })
    }

    output$table <- shiny::renderTable({
      dd <- filtered()$estimates
      cols <- intersect(c("analysis_id", "rr", "ci_95_lb", "ci_95_ub", "p",
                          "passesDiagnostics", decs), names(dd))
      utils::head(dd[, cols, drop = FALSE], 200)
    })

    output$dl <- shiny::downloadHandler(
      filename = function() paste0("multiverse_", format(Sys.Date(), "%Y%m%d"), ".csv"),
      content = function(file) exportMultiverse(filtered(), file)
    )
  }

  shiny::runApp(shiny::shinyApp(ui, server), ...)
}
