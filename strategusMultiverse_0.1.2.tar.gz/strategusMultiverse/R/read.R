#' Read a Strategus multiverse
#'
#' Locates CohortMethod results beneath a Strategus results folder, joins them to
#' study diagnostics, and recovers the specification grid (one column per
#' analytical decision that actually varies).
#'
#' File layouts differ across Strategus versions, so files are found by
#' recursive search rather than by fixed path.
#'
#' @param resultsFolder Path to the Strategus results folder, or any parent of it.
#' @param analysisSpecificationFile Optional path to `analysisSpecification.json`.
#'   If `NULL`, searched for beneath `resultsFolder`. This is the preferred source
#'   of the specification grid; `cm_analysis.csv` is used as a fallback.
#' @param targetId,comparatorId,outcomeId Optional filters. Required only when the
#'   results contain more than one target-comparator-outcome triplet.
#'
#' @return An object of class `strategus_multiverse`: a list with `estimates`
#'   (one row per specification), `decisions` (names of the varying decision
#'   columns), and `meta`.
#' @export
readStrategusMultiverse <- function(resultsFolder,
                                    analysisSpecificationFile = NULL,
                                    targetId = NULL,
                                    comparatorId = NULL,
                                    outcomeId = NULL) {
  checkmate::assertDirectoryExists(resultsFolder)

  resultFile <- .findOne(resultsFolder, "cm_result.csv")
  if (is.null(resultFile)) {
    stop("No 'cm_result.csv' found beneath '", resultsFolder, "'. ",
         "Is this a Strategus results folder containing CohortMethod output?")
  }

  results <- .readCsv(resultFile)

  # ---- filter to a single estimand ------------------------------------------
  results <- .filterTco(results, targetId, comparatorId, outcomeId)

  # ---- diagnostics (optional) -----------------------------------------------
  diagFile <- .findOne(resultsFolder, "cm_diagnostics_summary.csv")
  if (!is.null(diagFile)) {
    diag <- .readCsv(diagFile)
    joinCols <- intersect(
      c("analysis_id", "target_id", "comparator_id", "outcome_id", "database_id"),
      intersect(names(results), names(diag))
    )
    keep <- intersect(
      c(joinCols, "unblind", "mdrr", "ease", "max_sdm", "shared_max_sdm",
        "equipoise", "attrition_fraction", "mdrr_diagnostic", "ease_diagnostic",
        "balance_diagnostic", "shared_balance_diagnostic",
        "equipoise_diagnostic", "attrition_diagnostic",
        "generalizability_diagnostic"),
      names(diag)
    )
    results <- merge(results, diag[, keep, drop = FALSE], by = joinCols, all.x = TRUE)
  } else {
    message("No 'cm_diagnostics_summary.csv' found - diagnostic gating unavailable.")
  }

  # ---- specification grid ----------------------------------------------------
  if (is.null(analysisSpecificationFile)) {
    analysisSpecificationFile <- .findOne(resultsFolder, "analysisSpecification.json")
  }
  grid <- .extractSpecificationGrid(
    analysisSpecificationFile = analysisSpecificationFile,
    analysisCsv = .findOne(resultsFolder, "cm_analysis.csv")
  )

  estimates <- merge(results, grid$grid, by = "analysis_id", all.x = TRUE)

  # ---- derived columns -------------------------------------------------------
  estimates$estimable <- !is.na(estimates$rr) & is.finite(estimates$rr)
  if ("p" %in% names(estimates)) {
    estimates$significant <- !is.na(estimates$p) & estimates$p < 0.05
  }
  if ("unblind" %in% names(estimates)) {
    estimates$passesDiagnostics <- estimates$unblind %in% c(1, TRUE, "1", "TRUE")
  }
  estimates <- estimates[order(estimates$rr, na.last = TRUE), ]
  estimates$rank <- seq_len(nrow(estimates))

  structure(
    list(
      estimates = estimates,
      decisions = grid$decisions,
      meta = list(
        resultsFolder = normalizePath(resultsFolder),
        resultFile = resultFile,
        analysisSpecificationFile = analysisSpecificationFile,
        gridSource = grid$source,
        nSpecifications = nrow(estimates),
        nEstimable = sum(estimates$estimable),
        readAt = Sys.time()
      )
    ),
    class = "strategus_multiverse"
  )
}

#' @export
print.strategus_multiverse <- function(x, ...) {
  m <- x$meta
  cat("<strategus_multiverse>\n")
  cat("  specifications :", m$nSpecifications,
      sprintf("(%d estimable)\n", m$nEstimable))
  cat("  decisions      :", paste(x$decisions, collapse = ", "), "\n")
  cat("  grid source    :", m$gridSource, "\n")
  if ("passesDiagnostics" %in% names(x$estimates)) {
    cat("  pass diagnostics:", sum(x$estimates$passesDiagnostics, na.rm = TRUE),
        "/", m$nSpecifications, "\n")
  }
  est <- x$estimates$rr[x$estimates$estimable]
  if (length(est)) {
    cat("  estimate range :",
        sprintf("%.3f to %.3f", min(est), max(est)), "\n")
  }
  invisible(x)
}

# ---------------------------------------------------------------- internals

.findOne <- function(root, pattern) {
  hits <- list.files(root, pattern = paste0("^", pattern, "$"),
                     recursive = TRUE, full.names = TRUE)
  if (length(hits) == 0) return(NULL)
  if (length(hits) > 1) {
    warning("Multiple '", pattern, "' found; using ", hits[1])
  }
  hits[1]
}

.readCsv <- function(path) {
  df <- utils::read.csv(path, stringsAsFactors = FALSE)
  names(df) <- tolower(names(df))
  df
}

.filterTco <- function(results, targetId, comparatorId, outcomeId) {
  if (!is.null(targetId))     results <- results[results$target_id == targetId, ]
  if (!is.null(comparatorId)) results <- results[results$comparator_id == comparatorId, ]
  if (!is.null(outcomeId))    results <- results[results$outcome_id == outcomeId, ]

  tcoCols <- intersect(c("target_id", "comparator_id", "outcome_id"), names(results))
  if (length(tcoCols) == 3) {
    combos <- unique(results[, tcoCols])
    if (nrow(combos) > 1) {
      stop("Results contain ", nrow(combos), " target-comparator-outcome triplets. ",
           "A multiverse is defined for one estimand; specify targetId, ",
           "comparatorId and outcomeId.\nAvailable:\n",
           paste(utils::capture.output(print(combos)), collapse = "\n"))
    }
  }
  if (nrow(results) == 0) stop("No rows left after filtering.")
  results
}
