# Recover the specification grid: one column per analytical decision that varies.
#
# Preferred source is analysisSpecification.json, which holds the complete
# cmAnalysisList. Fallback is the `definition` column of cm_analysis.csv, which
# carries the same JSON per analysis but is more fragile across versions.

.extractSpecificationGrid <- function(analysisSpecificationFile = NULL,
                                      analysisCsv = NULL) {
  if (!is.null(analysisSpecificationFile) && file.exists(analysisSpecificationFile)) {
    out <- try(.gridFromAnalysisSpec(analysisSpecificationFile), silent = TRUE)
    if (!inherits(out, "try-error") && nrow(out$grid) > 0) return(out)
    warning("Could not parse the analysis specification; falling back to cm_analysis.csv.")
  }
  if (!is.null(analysisCsv) && file.exists(analysisCsv)) {
    return(.gridFromAnalysisCsv(analysisCsv))
  }
  stop("No specification source found: need analysisSpecification.json or cm_analysis.csv.")
}

.gridFromAnalysisSpec <- function(path) {
  spec <- jsonlite::fromJSON(path, simplifyVector = FALSE)
  analyses <- .findElement(spec, "cmAnalysisList")
  if (is.null(analyses)) stop("No 'cmAnalysisList' in the analysis specification.")

  rows <- lapply(analyses, function(a) .flatten(a))
  .assembleGrid(rows, source = "analysisSpecification.json")
}

.gridFromAnalysisCsv <- function(path) {
  df <- .readCsv(path)
  if (!"definition" %in% names(df)) {
    stop("'cm_analysis.csv' has no 'definition' column.")
  }
  rows <- lapply(seq_len(nrow(df)), function(i) {
    parsed <- try(jsonlite::fromJSON(df$definition[i], simplifyVector = FALSE),
                  silent = TRUE)
    if (inherits(parsed, "try-error")) return(c(analysisId = df$analysis_id[i]))
    flat <- .flatten(parsed)
    flat[["analysisId"]] <- df$analysis_id[i]
    flat
  })
  .assembleGrid(rows, source = "cm_analysis.csv")
}

# Flatten an arbitrarily nested list into a named character vector.
# Names are dot-separated paths; NULLs become "none" so that
# "argument absent" is itself a visible analytical choice.
.flatten <- function(x, prefix = "") {
  if (is.null(x)) {
    out <- "none"
    names(out) <- prefix
    return(out)
  }
  if (!is.list(x)) {
    if (length(x) == 0) x <- "none"
    out <- paste(as.character(x), collapse = "|")
    names(out) <- prefix
    return(out)
  }
  nms <- names(x)
  if (is.null(nms)) nms <- as.character(seq_along(x))
  parts <- mapply(
    function(el, nm) {
      .flatten(el, if (nzchar(prefix)) paste(prefix, nm, sep = ".") else nm)
    },
    x, nms, SIMPLIFY = FALSE
  )
  unlist(parts)
}

.assembleGrid <- function(rows, source) {
  allNames <- unique(unlist(lapply(rows, names)))
  mat <- do.call(rbind, lapply(rows, function(r) {
    v <- r[allNames]
    names(v) <- allNames
    v[is.na(v)] <- "not applicable"
    v
  }))
  grid <- as.data.frame(mat, stringsAsFactors = FALSE)

  # Drop R serialisation artifacts: ParallelLogger writes class/attribute
  # metadata into the JSON (e.g. "matchOnPsArgs.attr_class"). These differ
  # between analysis families and would otherwise look like decisions.
  artifact <- grepl("attr_|attributes|\\.class$|^class$", names(grid))
  grid <- grid[, !artifact, drop = FALSE]

  idCol <- grep("analysisId$", names(grid), value = TRUE)[1]
  if (is.na(idCol)) stop("Could not locate an analysisId in the specification.")
  grid$analysis_id <- as.integer(grid[[idCol]])

  # A decision is any field that takes more than one value across analyses.
  drop <- c(idCol, "analysis_id",
            grep("description|analysisId", names(grid), value = TRUE))
  candidates <- setdiff(names(grid), drop)
  varying <- candidates[vapply(candidates,
                               function(cn) length(unique(grid[[cn]])) > 1,
                               logical(1))]

  grid <- grid[, c("analysis_id", varying), drop = FALSE]
  names(grid) <- c("analysis_id", .prettyNames(varying))

  list(grid = grid, decisions = .prettyNames(varying), source = source)
}

# Strip nesting noise: "matchOnPsArgs.caliper" -> "caliper"; keep the
# distinguishing prefix only when the leaf name would collide.
.prettyNames <- function(x) {
  leaf <- sub(".*\\.", "", x)
  dup <- leaf %in% leaf[duplicated(leaf)]
  nm <- ifelse(dup, gsub("Args\\.", "_", x), leaf)
  # Must be safe as a Shiny input id and as a data frame column name.
  nm <- gsub("[^A-Za-z0-9_.]+", "_", nm)
  nm <- sub("^([^A-Za-z.])", "x\\1", nm)
  make.unique(nm, sep = "_")
}

# Depth-first search for the first element with a given name.
.findElement <- function(x, name) {
  if (!is.list(x)) return(NULL)
  if (!is.null(names(x)) && name %in% names(x)) return(x[[name]])
  for (el in x) {
    hit <- .findElement(el, name)
    if (!is.null(hit)) return(hit)
  }
  NULL
}
