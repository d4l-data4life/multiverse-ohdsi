#' Visualise a Strategus multiverse
#'
#' @param x A `strategus_multiverse`, or a path to a Strategus results folder.
#' @param type Visualisation to produce:
#'   \describe{
#'     \item{`"specification_curve"`}{Simonsohn et al. curve: ranked estimates
#'       over a decision dashboard. Degrades above roughly 200-300 specifications.}
#'     \item{`"multiverse"`}{Krahmer & Young multiverse plot: density of the
#'       modelling distribution over a binned dashboard with influence
#'       coefficients. Scales to thousands of specifications.}
#'     \item{`"density"`}{Density alone, significant subset shaded.}
#'     \item{`"volcano"`}{Vibration of effects: -log10(p) against the estimate.}
#'     \item{`"volcano_interactive"`}{As above, with a hover tooltip giving the
#'       full specification, counts and diagnostics for each point. Requires
#'       \pkg{plotly}.}
#'     \item{`"influence"`}{Influence coefficients only, from an OLS
#'       meta-regression of the estimate on the decision indicators.}
#'     \item{`"gate"`}{Estimates before and after the OHDSI diagnostic gate.}
#'     \item{`"shiny"`}{Launch the interactive explorer.}
#'   }
#' @param estimate Column holding the point estimate. `"rr"` or, where negative
#'   controls were included, `"calibrated_rr"`.
#' @param diagnosticsOnly Restrict to specifications that pass study diagnostics.
#' @param log Plot the estimate on the log scale. Sensible for ratio measures.
#' @param ... Passed to the individual plot functions.
#'
#' @return A `ggplot` object, or for `type = "shiny"` a running app.
#' @export
#' @examples
#' \dontrun{
#' multiverse("resultsFolder", type = "specification_curve")
#' multiverse("resultsFolder", type = "multiverse")
#' multiverse("resultsFolder", type = "shiny")
#' }
multiverse <- function(x,
                       type = c("specification_curve", "multiverse", "density",
                                "volcano", "volcano_interactive", "influence",
                                "gate", "shiny"),
                       estimate = "rr",
                       diagnosticsOnly = FALSE,
                       log = TRUE,
                       ...) {
  type <- match.arg(type)
  if (is.character(x)) x <- readStrategusMultiverse(x)
  stopifnot(inherits(x, "strategus_multiverse"))

  if (diagnosticsOnly) {
    if (!"passesDiagnostics" %in% names(x$estimates)) {
      stop("No diagnostics available; cannot use diagnosticsOnly = TRUE.")
    }
    x$estimates <- x$estimates[which(x$estimates$passesDiagnostics), ]
  }

  switch(
    type,
    specification_curve = plotSpecificationCurve(x, estimate, log, ...),
    multiverse          = plotMultiversePlot(x, estimate, log, ...),
    density             = plotDensity(x, estimate, log, ...),
    volcano             = plotVolcano(x, estimate, log, ...),
    volcano_interactive = plotVolcanoInteractive(x, estimate, log, ...),
    influence           = plotInfluence(x, estimate, log, ...),
    gate                = plotGate(x, estimate, log, ...),
    shiny               = launchMultiverseApp(x, ...)
  )
}

#' @export
#' @rdname multiverse
plot.strategus_multiverse <- function(x, type = "specification_curve", ...) {
  multiverse(x, type = type, ...)
}

.prep <- function(x, estimate, log) {
  d <- x$estimates
  if (!estimate %in% names(d)) {
    stop("Column '", estimate, "' not in results. Available: ",
         paste(intersect(c("rr", "calibrated_rr"), names(d)), collapse = ", "))
  }
  d <- d[!is.na(d[[estimate]]) & is.finite(d[[estimate]]), ]
  if (nrow(d) == 0) stop("No estimable specifications.")
  d$.est <- if (log) log(d[[estimate]]) else d[[estimate]]
  d <- d[order(d$.est), ]
  d$.rank <- seq_len(nrow(d))
  d
}

.nullLine <- function(log) if (log) 0 else 1

# --------------------------------------------------------------- spec curve

#' @export
plotSpecificationCurve <- function(x, estimate = "rr", log = TRUE, ...) {
  d <- .prep(x, estimate, log)
  if (nrow(d) > 300) {
    warning(nrow(d), " specifications. Specification curves lose the decision ",
            "dashboard above ~200-300; consider type = 'multiverse'.")
  }
  sig <- if ("significant" %in% names(d)) d$significant else NA

  lb <- if (all(c("ci_95_lb", "ci_95_ub") %in% names(d))) {
    if (log) log(d$ci_95_lb) else d$ci_95_lb
  } else NULL
  ub <- if (!is.null(lb)) { if (log) log(d$ci_95_ub) else d$ci_95_ub } else NULL

  top <- ggplot2::ggplot(d, ggplot2::aes(x = .rank, y = .est))
  if (!is.null(lb)) {
    top <- top + ggplot2::geom_linerange(
      ggplot2::aes(ymin = lb, ymax = ub, colour = sig), alpha = 0.5)
  }
  top <- top +
    ggplot2::geom_point(ggplot2::aes(colour = sig), size = 1.4) +
    ggplot2::geom_hline(yintercept = .nullLine(log), linetype = "dashed") +
    ggplot2::scale_colour_manual(
      values = c("FALSE" = "#4C72B0", "TRUE" = "#C44E52"),
      labels = c("Not significant", "p < 0.05"), name = NULL,
      na.value = "#4C72B0") +
    ggplot2::labs(x = NULL, y = if (log) "log(estimate)" else "Estimate") +
    ggplot2::theme_minimal() +
    ggplot2::theme(axis.text.x = ggplot2::element_blank(),
                   legend.position = "top")

  bottom <- .dashboard(d, x$decisions)
  .stack(top, bottom, heights = c(2, 3))
}

.dashboard <- function(d, decisions) {
  long <- do.call(rbind, lapply(decisions, function(dec) {
    data.frame(rank = d$.rank, decision = dec,
               value = as.character(d[[dec]]), stringsAsFactors = FALSE)
  }))
  long <- long[long$value != "not applicable", ]

  ggplot2::ggplot(long, ggplot2::aes(x = rank, y = value)) +
    ggplot2::geom_point(shape = 15, size = 1.1, colour = "#4C72B0") +
    ggplot2::facet_grid(decision ~ ., scales = "free_y", space = "free_y",
                        switch = "y") +
    ggplot2::labs(x = "Specification (ranked by estimate)", y = NULL) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      axis.text.x = ggplot2::element_blank(),
      strip.placement = "outside",
      strip.text.y.left = ggplot2::element_text(angle = 0, hjust = 1),
      panel.grid.major.x = ggplot2::element_blank()
    )
}

# --------------------------------------------------- Krahmer & Young plot

#' @export
plotMultiversePlot <- function(x, estimate = "rr", log = TRUE, bins = 30, ...) {
  d <- .prep(x, estimate, log)
  brks <- seq(min(d$.est), max(d$.est), length.out = bins + 1)
  d$.bin <- cut(d$.est, breaks = brks, include.lowest = TRUE, labels = FALSE)
  binMid <- (brks[-1] + brks[-length(brks)]) / 2

  top <- ggplot2::ggplot(d, ggplot2::aes(x = .est)) +
    ggplot2::geom_density(colour = "#4C72B0", linewidth = 0.9)
  if ("significant" %in% names(d) && any(d$significant, na.rm = TRUE)) {
    top <- top + ggplot2::geom_density(
      data = d[which(d$significant), ],
      fill = "#C44E52", colour = NA, alpha = 0.35)
  }
  top <- top +
    ggplot2::geom_vline(xintercept = .nullLine(log), linetype = "dashed") +
    ggplot2::labs(x = NULL, y = "Density") +
    ggplot2::theme_minimal()

  # binned dashboard: share of each option within each estimate bin
  long <- do.call(rbind, lapply(x$decisions, function(dec) {
    data.frame(bin = d$.bin, decision = dec,
               value = as.character(d[[dec]]), stringsAsFactors = FALSE)
  }))
  long <- long[long$value != "not applicable", ]
  agg <- stats::aggregate(list(n = rep(1, nrow(long))),
                          by = list(bin = long$bin, decision = long$decision,
                                    value = long$value), FUN = sum)
  tot <- stats::aggregate(list(tot = agg$n),
                          by = list(bin = agg$bin, decision = agg$decision),
                          FUN = sum)
  agg <- merge(agg, tot, by = c("bin", "decision"))
  agg$share <- agg$n / agg$tot
  agg$x <- binMid[agg$bin]

  bottom <- ggplot2::ggplot(agg, ggplot2::aes(x = x, y = value, fill = share)) +
    ggplot2::geom_tile() +
    ggplot2::facet_grid(decision ~ ., scales = "free_y", space = "free_y",
                        switch = "y") +
    ggplot2::scale_fill_gradient(low = "white", high = "#4C72B0",
                                 name = "Share", limits = c(0, 1)) +
    ggplot2::labs(x = if (log) "log(estimate)" else "Estimate", y = NULL) +
    ggplot2::theme_minimal() +
    ggplot2::theme(strip.placement = "outside",
                   strip.text.y.left = ggplot2::element_text(angle = 0, hjust = 1))

  .stack(top, bottom, heights = c(2, 3))
}

# --------------------------------------------------------------- others

#' @export
plotDensity <- function(x, estimate = "rr", log = TRUE, ...) {
  d <- .prep(x, estimate, log)
  p <- ggplot2::ggplot(d, ggplot2::aes(x = .est)) +
    ggplot2::geom_density(colour = "#4C72B0", linewidth = 0.9)
  if ("significant" %in% names(d) && any(d$significant, na.rm = TRUE)) {
    p <- p + ggplot2::geom_density(data = d[which(d$significant), ],
                                   fill = "#C44E52", colour = NA, alpha = 0.35)
  }
  p + ggplot2::geom_vline(xintercept = .nullLine(log), linetype = "dashed") +
    ggplot2::labs(x = if (log) "log(estimate)" else "Estimate", y = "Density") +
    ggplot2::theme_minimal()
}

#' @export
plotVolcano <- function(x, estimate = "rr", log = TRUE, colourBy = NULL, ...) {
  d <- .prep(x, estimate, log)
  if (!"p" %in% names(d)) stop("No 'p' column; cannot draw a volcano plot.")
  d$.negLogP <- -log10(pmax(d$p, .Machine$double.xmin))
  aes <- if (!is.null(colourBy)) {
    ggplot2::aes(x = .est, y = .negLogP, colour = .data[[colourBy]])
  } else {
    ggplot2::aes(x = .est, y = .negLogP)
  }
  ggplot2::ggplot(d, aes) +
    ggplot2::geom_point(alpha = 0.7, size = 1.6) +
    ggplot2::geom_hline(yintercept = -log10(0.05), colour = "#C44E52",
                        linetype = "dashed") +
    ggplot2::geom_vline(xintercept = .nullLine(log), colour = "#55A868",
                        linetype = "dashed") +
    ggplot2::labs(x = if (log) "log(estimate)" else "Estimate",
                  y = expression(-log[10](p))) +
    ggplot2::theme_minimal()
}

# Build a hover label for one specification: identity, estimate, counts,
# diagnostics, and every analytical decision behind it.
.tooltipText <- function(d, decisions, estimate) {
  fmt <- function(v, digits = 3) {
    ifelse(is.na(v), "NA", formatC(as.numeric(v), format = "f", digits = digits))
  }
  lines <- paste0("Analysis ", d$analysis_id)

  if ("description" %in% names(d)) {
    lines <- paste0(lines, "\n", d$description)
  }

  est <- fmt(d[[estimate]])
  if (all(c("ci_95_lb", "ci_95_ub") %in% names(d))) {
    est <- paste0(est, " (", fmt(d$ci_95_lb), " to ", fmt(d$ci_95_ub), ")")
  }
  lines <- paste0(lines, "\n", estimate, ": ", est)

  if ("p" %in% names(d)) {
    lines <- paste0(lines, "\np = ", format.pval(d$p, digits = 3, eps = 1e-4))
  }

  if (all(c("target_subjects", "comparator_subjects") %in% names(d))) {
    lines <- paste0(lines, "\nSubjects: ", d$target_subjects, " vs ",
                    d$comparator_subjects)
  }
  if (all(c("target_outcomes", "comparator_outcomes") %in% names(d))) {
    lines <- paste0(lines, "\nOutcomes: ", d$target_outcomes, " vs ",
                    d$comparator_outcomes)
  }

  diag <- character(nrow(d))
  if ("passesDiagnostics" %in% names(d)) {
    diag <- ifelse(d$passesDiagnostics, "passes", "PRUNED")
  }
  if ("max_sdm" %in% names(d)) {
    diag <- paste0(diag, ifelse(nzchar(diag), ", ", ""), "max SDM ", fmt(d$max_sdm, 2))
  }
  if ("mdrr" %in% names(d)) {
    diag <- paste0(diag, ifelse(nzchar(diag), ", ", ""), "MDRR ", fmt(d$mdrr, 2))
  }
  if (any(nzchar(diag))) lines <- paste0(lines, "\nDiagnostics: ", diag)

  if (length(decisions)) {
    specTxt <- Reduce(function(acc, dn) {
      val <- as.character(d[[dn]])
      add <- ifelse(val == "not applicable", "",
                    paste0("\n  ", dn, " = ", val))
      paste0(acc, add)
    }, decisions, init = rep("", nrow(d)))
    lines <- paste0(lines, "\nSpecification:", specTxt)
  }
  lines
}

#' Interactive volcano plot
#'
#' Vibration of effects with a hover tooltip carrying the full specification,
#' counts and diagnostics for each point.
#'
#' @inheritParams multiverse
#' @param colourBy Optional decision name to colour points by.
#' @return A \pkg{plotly} object.
#' @export
plotVolcanoInteractive <- function(x, estimate = "rr", log = TRUE,
                                   colourBy = NULL, ...) {
  if (!requireNamespace("plotly", quietly = TRUE)) {
    stop("Install 'plotly' for the interactive volcano plot:\n",
         "  install.packages('plotly')\n",
         "Or use type = 'volcano' for the static version.")
  }
  d <- .prep(x, estimate, log)
  if (!"p" %in% names(d)) stop("No 'p' column; cannot draw a volcano plot.")
  d$.negLogP <- -log10(pmax(d$p, .Machine$double.xmin))
  d$.tooltip <- .tooltipText(d, x$decisions, estimate)

  if (!is.null(colourBy) && !colourBy %in% names(d)) {
    stop("colourBy = '", colourBy, "' is not a decision. Available: ",
         paste(x$decisions, collapse = ", "))
  }

  mapping <- if (!is.null(colourBy)) {
    ggplot2::aes(x = .est, y = .negLogP, text = .tooltip,
                 colour = .data[[colourBy]])
  } else if ("passesDiagnostics" %in% names(d)) {
    ggplot2::aes(x = .est, y = .negLogP, text = .tooltip,
                 colour = passesDiagnostics)
  } else {
    ggplot2::aes(x = .est, y = .negLogP, text = .tooltip)
  }

  p <- ggplot2::ggplot(d, mapping) +
    ggplot2::geom_point(alpha = 0.8, size = 2) +
    ggplot2::geom_hline(yintercept = -log10(0.05), colour = "#C44E52",
                        linetype = "dashed") +
    ggplot2::geom_vline(xintercept = .nullLine(log), colour = "#55A868",
                        linetype = "dashed") +
    ggplot2::labs(x = if (log) "log(estimate)" else "Estimate",
                  y = "-log10(p)", colour = NULL) +
    ggplot2::theme_minimal()

  # ggplot2 does not know the 'text' aesthetic; plotly does.
  suppressWarnings(
    plotly::ggplotly(p, tooltip = "text") |>
      plotly::layout(hoverlabel = list(align = "left"))
  )
}

#' @export
plotGate <- function(x, estimate = "rr", log = TRUE, ...) {
  if (!"passesDiagnostics" %in% names(x$estimates)) {
    stop("No diagnostics available. Ensure 'cm_diagnostics_summary.csv' is present.")
  }
  d <- .prep(x, estimate, log)
  d$panel <- ifelse(d$passesDiagnostics, "Passes diagnostics", "Pruned")
  both <- rbind(
    transform(d, panel = "All specifications"),
    d[which(d$passesDiagnostics), ]
  )
  both$panel <- factor(both$panel,
                       levels = c("All specifications", "Passes diagnostics"))
  ggplot2::ggplot(both, ggplot2::aes(x = .est)) +
    ggplot2::geom_density(colour = "#4C72B0", linewidth = 0.9) +
    ggplot2::geom_rug(alpha = 0.4) +
    ggplot2::geom_vline(xintercept = .nullLine(log), linetype = "dashed") +
    ggplot2::facet_wrap(~panel, ncol = 1, scales = "free_y") +
    ggplot2::labs(x = if (log) "log(estimate)" else "Estimate", y = "Density",
                  title = "Does the diagnostic gate narrow the dispersion?") +
    ggplot2::theme_minimal()
}

# stack two ggplots without hard-depending on patchwork
.stack <- function(top, bottom, heights = c(1, 1)) {
  if (requireNamespace("patchwork", quietly = TRUE)) {
    return(patchwork::wrap_plots(top, bottom, ncol = 1, heights = heights))
  }
  if (requireNamespace("cowplot", quietly = TRUE)) {
    return(cowplot::plot_grid(top, bottom, ncol = 1, align = "v",
                              rel_heights = heights))
  }
  warning("Install 'patchwork' or 'cowplot' to combine panels; returning a list.")
  list(top = top, bottom = bottom)
}
