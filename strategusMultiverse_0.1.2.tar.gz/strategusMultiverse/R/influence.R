#' Influence of each analytical decision
#'
#' OLS meta-regression of the estimate on indicator variables for each decision
#' option, as in Krahmer & Young. Coefficients give the average change in the
#' estimate from departing from the reference option.
#'
#' @param x A `strategus_multiverse`.
#' @param estimate Column holding the point estimate.
#' @param log Regress on the log estimate.
#' @param reference Optional named character vector giving the reference option
#'   for chosen decisions, e.g. `c(caliper = "0.2")`. Defaults to the first level.
#' @return A data frame of decisions, options, coefficients and standard errors.
#' @export
influence <- function(x, estimate = "rr", log = TRUE, reference = NULL) {
  d <- .prep(x, estimate, log)
  decs <- x$decisions[vapply(x$decisions,
                             function(dn) length(unique(d[[dn]])) > 1,
                             logical(1))]
  if (length(decs) == 0) stop("No decision varies among estimable specifications.")

  for (dn in decs) {
    d[[dn]] <- factor(d[[dn]])
    if (!is.null(reference) && dn %in% names(reference) &&
        reference[[dn]] %in% levels(d[[dn]])) {
      d[[dn]] <- stats::relevel(d[[dn]], ref = reference[[dn]])
    }
  }

  form <- stats::as.formula(paste(".est ~", paste(sprintf("`%s`", decs),
                                                  collapse = " + ")))
  fit <- stats::lm(form, data = d)
  co <- summary(fit)$coefficients
  co <- co[rownames(co) != "(Intercept)", , drop = FALSE]

  out <- data.frame(
    term = rownames(co),
    coefficient = co[, 1],
    se = co[, 2],
    statistic = co[, 3],
    p = co[, 4],
    stringsAsFactors = FALSE, row.names = NULL
  )
  out$decision <- NA_character_
  for (dn in decs) {
    hit <- startsWith(out$term, paste0("`", dn, "`")) | startsWith(out$term, dn)
    out$decision[hit] <- dn
  }
  out$option <- mapply(function(tm, dn) {
    sub(paste0("^`?", dn, "`?"), "", tm)
  }, out$term, out$decision)

  out$rSquared <- summary(fit)$r.squared
  out[order(-abs(out$coefficient)), c("decision", "option", "coefficient",
                                      "se", "statistic", "p", "rSquared")]
}

#' @export
plotInfluence <- function(x, estimate = "rr", log = TRUE, ...) {
  inf <- influence(x, estimate, log, ...)
  inf$label <- paste0(inf$decision, ": ", inf$option)
  inf$label <- factor(inf$label, levels = inf$label[order(inf$coefficient)])
  ggplot2::ggplot(inf, ggplot2::aes(x = coefficient, y = label)) +
    ggplot2::geom_vline(xintercept = 0, linetype = "dashed") +
    ggplot2::geom_errorbarh(
      ggplot2::aes(xmin = coefficient - 1.96 * se,
                   xmax = coefficient + 1.96 * se), height = 0) +
    ggplot2::geom_point(size = 2.2, colour = "#4C72B0") +
    ggplot2::labs(
      x = paste0("Average change in ", if (log) "log(estimate)" else "estimate"),
      y = NULL,
      caption = sprintf("OLS meta-regression, R-squared = %.2f", inf$rSquared[1])) +
    ggplot2::theme_minimal()
}

#' Variance decomposition across analytical decisions
#'
#' ANOVA of the estimate on the decision factors, reporting the share of
#' explained variance attributable to each. Also returns the relative estimate
#' ratio and relative p-value used as vibration-of-effects measures.
#'
#' Note the shares are a property of the option set that was enumerated, not of
#' the decision category in the abstract: widening or narrowing the options
#' within a decision changes its share. Report the grid alongside the numbers.
#'
#' @inheritParams influence
#' @return A list with `variance` (decomposition table) and `vibration`.
#' @export
varianceDecomposition <- function(x, estimate = "rr", log = TRUE) {
  d <- .prep(x, estimate, log)
  decs <- x$decisions[vapply(x$decisions,
                             function(dn) length(unique(d[[dn]])) > 1,
                             logical(1))]
  if (length(decs) == 0) stop("No decision varies among estimable specifications.")

  form <- stats::as.formula(paste(".est ~", paste(sprintf("`%s`", decs),
                                                  collapse = " + ")))
  av <- stats::anova(stats::lm(form, data = d))
  ss <- av[["Sum Sq"]]
  variance <- data.frame(
    source = rownames(av),
    sumSq = ss,
    percentExplained = 100 * ss / sum(ss),
    stringsAsFactors = FALSE, row.names = NULL
  )

  est <- d[[estimate]]
  q <- stats::quantile(est, c(0.01, 0.99), na.rm = TRUE)
  vibration <- list(
    relativeEstimateRatio = unname(q[2] / q[1]),
    range = unname(q)
  )
  if ("p" %in% names(d)) {
    lp <- -log10(pmax(d$p, .Machine$double.xmin))
    qp <- stats::quantile(lp, c(0.01, 0.99), na.rm = TRUE)
    vibration$relativeP <- unname(qp[2] - qp[1])
  }
  list(variance = variance[order(-variance$percentExplained), ],
       vibration = vibration)
}

#' @export
summary.strategus_multiverse <- function(object, estimate = "rr", ...) {
  d <- object$estimates
  est <- d[[estimate]][d$estimable]
  out <- list(
    nSpecifications = nrow(d),
    nEstimable = length(est),
    median = stats::median(est),
    range = range(est),
    percentAboveNull = 100 * mean(est > 1),
    percentSignificant = if ("significant" %in% names(d))
      100 * mean(d$significant, na.rm = TRUE) else NA_real_,
    percentPassingDiagnostics = if ("passesDiagnostics" %in% names(d))
      100 * mean(d$passesDiagnostics, na.rm = TRUE) else NA_real_,
    decisions = object$decisions
  )
  class(out) <- "summary.strategus_multiverse"
  out
}

#' @export
print.summary.strategus_multiverse <- function(x, ...) {
  cat("Multiverse summary\n------------------\n")
  cat(sprintf("Specifications      : %d (%d estimable)\n",
              x$nSpecifications, x$nEstimable))
  cat(sprintf("Median estimate     : %.3f\n", x$median))
  cat(sprintf("Range               : %.3f to %.3f\n", x$range[1], x$range[2]))
  cat(sprintf("Above the null      : %.1f%%\n", x$percentAboveNull))
  if (!is.na(x$percentSignificant))
    cat(sprintf("Significant         : %.1f%%\n", x$percentSignificant))
  if (!is.na(x$percentPassingDiagnostics))
    cat(sprintf("Pass diagnostics    : %.1f%%\n", x$percentPassingDiagnostics))
  cat("Decisions           :", paste(x$decisions, collapse = ", "), "\n")
  invisible(x)
}

#' Export a multiverse to a tidy, tool-agnostic table
#'
#' One row per specification, with the estimate, interval, diagnostics and one
#' column per decision. This is the interchange format for external tooling:
#' the Krahmer & Young Stata/R scripts, or a Comet-style pipeline.
#'
#' @param x A `strategus_multiverse`.
#' @param file Output path. Extension determines the format (`.csv` or `.json`).
#' @export
exportMultiverse <- function(x, file) {
  keep <- intersect(
    c("analysis_id", "rank", "rr", "ci_95_lb", "ci_95_ub", "p",
      "calibrated_rr", "calibrated_ci_95_lb", "calibrated_ci_95_ub",
      "calibrated_p", "log_rr", "se_log_rr",
      "target_subjects", "comparator_subjects",
      "target_outcomes", "comparator_outcomes",
      "estimable", "significant", "passesDiagnostics",
      "mdrr", "max_sdm", "equipoise"),
    names(x$estimates)
  )
  out <- x$estimates[, c(keep, x$decisions), drop = FALSE]
  if (grepl("\\.json$", file)) {
    jsonlite::write_json(out, file, dataframe = "rows", auto_unbox = TRUE,
                         pretty = TRUE)
  } else {
    utils::write.csv(out, file, row.names = FALSE)
  }
  invisible(normalizePath(file))
}
